<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TestimonialController extends Controller
{
    public function create ()
    {
        return view('testimonial.create');
    }

    public function postCreate() {
        // receive the form submission, and save the new testimonial in our database
    }
}

