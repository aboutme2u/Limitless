<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/business', function () {
    return view('business');
})->name('business');

Route::get('/about_us', function() {
    return view('about_us');
})->name('about_us');

Route::get('/personal', function() {
    return view('personal');
})->name('personal');

Route::get('/promotion', function () {
    return view('promotion');
})->name('promotion');

Route::get('/EZ Port', function() {
    return view('EZ Port');
})->name('about_us');

Route::get('/help', function() {
    return view('help');
})->name('help');

Route::get('/', function () {
    return view('welcome');
});




Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/profile', [App\Http\Controllers\ProfileController::class, 'index'])->name('profile');
Route::get('/profile/create', [App\Http\Controllers\ProfileController::class, 'create']);
Route::post('/profile/postCreate', [App\Http\Controllers\ProfileController::class, 'postCreate'])->name('profile.postCreate');
Route::get('/profile/edit', [App\Http\Controllers\ProfileController::class, 'edit']);
Route::post('/profile/{id}/postEdit', [App\Http\Controllers\ProfileController::class, 'postEdit'])->name('profile.postEdit');

Route::resource('post', App\Http\Controllers\PostController::class);

Route::get('/plans', [App\Http\Controllers\ProfileController::class, 'getPlans']);
Route::get('/plans/subscribe/basic', [App\Http\Controllers\ProfileController::class, 'subscribeBasic']);
Route::get('/plans/subscribe/pro', [App\Http\Controllers\ProfileController::class, 'subscribePro']);
Route::get('/plans/subscribe/premium', [App\Http\Controllers\ProfileController::class, 'subscribePremium']);

Route::get('/testimonial', [App\Http\Controllers\TestimonialController::class, 'create']);
Route::post('/testimonial/postCreate', [App\Http\Controllers\TestimonialController::class, 'postCreate'])->name('testimonial.postCreate');

Route::post('/promotion/postCreate', [App\Http\Controllers\TestimonialController::class, 'postCreate'])->name('promotion.postCreate'); 