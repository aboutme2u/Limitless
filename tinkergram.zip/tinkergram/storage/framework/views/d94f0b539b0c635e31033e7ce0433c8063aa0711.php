<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row justify-content-center">
       <div class="col-md-3">
           <img class="rounded-circle" width="150" src="/storage/<?php echo e($profile->image); ?>">
       </div>
       <div class="col-md-9">
           <h3><?php echo e($user->name); ?></h3>
           <span><strong><?php echo e($numPosts); ?></strong> posts</span>
           <div class="pt-3"><?php echo e($profile->description); ?></div>
            <div class="pt-3"><a href="/profile/edit">Edit profile</a></div>
       </div>
   </div>
    <div class="row pt-5">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4 mb-5">
                <a href="/post/<?php echo e($post->id); ?>">
                    <span><?php echo e($post->caption); ?></span>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yr/Desktop/tinkergram/resources/views/profile.blade.php ENDPATH**/ ?>