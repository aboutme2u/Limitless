<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-8">
            <img src="/storage/<?php echo e($post->image); ?>" class="w-100">
        </div>
        <div class="col-4">
            <h2><?php echo e($user->name); ?></h2>
            <p> <?php echo e($post->caption); ?></p>
            <form action="<?php echo e(route('post.destroy', ['post' => $post->id])); ?>" enctype="multipart/form-data" method="post">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('DELETE')); ?>

                <div class="form-group row">
                    <button type="submit" class="btn btn-primary">Delete</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yr/Desktop/tinkergram/resources/views/post/show.blade.php ENDPATH**/ ?>