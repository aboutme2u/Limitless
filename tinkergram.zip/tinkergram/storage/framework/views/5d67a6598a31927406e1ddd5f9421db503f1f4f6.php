<html>
<head>
<link rel="stylesheet" type="text/css" href="feedback_style.css">
<script type="text/javascript" src="jquery.js">
<script type="text/javascript">

$(document).ready(function(){
  $("#feedback_button").click(function(){
    form();
  });
});
	
function form()
{
  $("form").slideToggle();
}
</script>


<body>

    

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-4"></div>
            <div class="col-4">
                <form action="<?php echo e(route('post.store')); ?>" enctype="multipart/form-data" method="post">
                    <?php echo csrf_field(); ?>

                    <div id="form">
                        <p id="feedback_button">Feedback</p>
                        
                    <form method="post" action="">

                    <div class="form-group row">
                        <label for="caption">Name</label>
                        <input class="form-control" type="text" name="caption" id="caption">
                    </div>        

                    <div class="form-group row">
                        <label for="caption">Email</label>
                        <input class="form-control" type="text" name="caption" id="caption">
                    </div>        

                    <div class="form-group row">
                        <label for="caption">Feedback</label>
                        <input class="form-control" type="text" name="caption" id="caption">
                    </div>

                    <div class="form-group row">
                        <label for="caption">Caption</label>
                        <input class="form-control" type="text" name="caption" id="caption">
                    </div>

                    <div class="form-group row">
                        <label for="postpic">enter you testimonial</label>
                        <input type="file" name="postpic" id="postpic">
                    </div>

                    <div class="form-group row">
                        <button type="submit" class="btn btn-primary">Post!</button>
                    </div>
                </form>
            </div>
            <div class="col-4"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yr/Desktop/tinkergram/resources/views/testimonial/create.blade.php ENDPATH**/ ?>