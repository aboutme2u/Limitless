<?php $__env->startSection('content'); ?>
   <div class="container">
       <div class="row">
           <div class="col-4"></div>
           <div class="col-4">
               <form action="<?php echo e(route('profile.postEdit', ['id' => $profile->id])); ?>" enctype="multipart/form-data" method="post">
                   <?php echo csrf_field(); ?>
                   <?php if($profile == null): ?>
                       <div>where my profile</div>
                   <?php endif; ?>
                   <div class="form-group row">
                       <label for="description">Description</label>
                       <input class="form-control" type="text" name="description" id="description"
                           value="<?php echo e($profile->description); ?>">
                   </div>

                   <div class="form-group row">
                       <label for="profilepic">Profile picture</label>
                       <input type="file" name="profilepic" id="profilepic">
                   </div>

                   <div class="form-group row">
                       <button type="submit" class="btn btn-primary">Create profile</button>
                   </div>
               </form>
           </div>
           <div class="col-4"></div>
       </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yr/Desktop/tinkergram/resources/views/editProfile.blade.php ENDPATH**/ ?>